# loki_a2
<h2>SI Manajemen RPS</h2>

<h3>Kelompok 2</h3>

Anggota Kelompok :
1. Nada Safarina              2011521015
2. Dwisuci Insani Karimah     2011522011
3. Annisa Ulfa                2011522015
4. Muhammad Rayhan Rizaldi    2011522021
5. Boby Darmawan              2011522023


<h3>Progress Project</h3> 

   <h4>A. Frontend</h4>
     <li>Desain front end telah selesai</li>

   <h4>B. Backend</h4>
     <li>Mampu memahami struktur database dan scope project</li>
     <li>Mampu membuat web server dan merespon request pengguna dengan menggunakan ExpressJS</li>
     <li>Mampu membuat router</li>
     <li>Mampu mendesain RestFul API dan struktur data JSON</li>
     <li>Aplikasi sudah terkoneksi ke database</li>
     <li>Aplikasi memiliki fitur login dan logout</li>
